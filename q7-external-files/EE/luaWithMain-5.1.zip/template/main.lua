local function main()
	print "custom main here"
end
main()
